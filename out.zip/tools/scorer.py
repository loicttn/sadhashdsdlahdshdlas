class Scorer:
    def __init__(self):
        self.a = "a"
